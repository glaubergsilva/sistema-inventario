package main

import (
	"io/fs"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

const (
	profundidadeMaxima  = 3     // níveis listados abaixo da área de trabalho
	maxItensListados    = 2000  // por área de trabalho
	maxEntradasVarridas = 50000 // limite de segurança da varredura
)

var nomesIgnorados = map[string]bool{
	"desktop.ini": true,
	"thumbs.db":   true,
	".ds_store":   true,
}

var extensoesIgnoradas = map[string]bool{
	".lnk": true, // atalhos
	".url": true, // atalhos de internet
	".tmp": true,
}

func ignorar(nome string) bool {
	n := strings.ToLower(nome)
	if nomesIgnorados[n] || strings.HasPrefix(n, "~$") {
		return true
	}
	return extensoesIgnoradas[strings.ToLower(filepath.Ext(n))]
}

// varrerAreaTrabalho lista arquivos e pastas de uma área de trabalho.
// Apenas metadados (nome, tamanho, data) são coletados — nunca o conteúdo.
// limite: tempo máximo da varredura (0 = sem limite); ao estourar, envia o que já foi lido.
func varrerAreaTrabalho(usuario, raiz string, limite time.Duration) AreaTrabalho {
	at := AreaTrabalho{Usuario: usuario, Caminho: raiz, Itens: []ItemAreaTrabalho{}}
	var prazo time.Time
	if limite > 0 {
		prazo = time.Now().Add(limite)
	}

	type acumulado struct {
		bytes    int64
		arquivos int
	}
	pastas := map[string]*acumulado{} // rel -> totais
	indicePasta := map[string]int{}   // rel -> índice em at.Itens
	varridas := 0

	_ = filepath.WalkDir(raiz, func(caminho string, d fs.DirEntry, err error) error {
		if err != nil {
			if d != nil && d.IsDir() && caminho != raiz {
				return fs.SkipDir
			}
			return nil
		}
		if caminho == raiz {
			return nil
		}
		varridas++
		if varridas > maxEntradasVarridas || (!prazo.IsZero() && varridas%200 == 0 && time.Now().After(prazo)) {
			at.Truncado = true
			at.TempoEsgotado = varridas <= maxEntradasVarridas
			return fs.SkipAll
		}
		if ignorar(d.Name()) {
			if d.IsDir() {
				return fs.SkipDir
			}
			return nil
		}
		// não segue links simbólicos / junções
		if d.Type()&fs.ModeSymlink != 0 || d.Type()&fs.ModeIrregular != 0 {
			return nil
		}

		rel, _ := filepath.Rel(raiz, caminho)
		rel = filepath.ToSlash(rel)
		nivel := strings.Count(rel, "/") + 1

		info, errInfo := d.Info()
		if errInfo != nil {
			return nil
		}
		mod := info.ModTime().Format(time.RFC3339)

		if d.IsDir() {
			at.TotalPastas++
			pastas[rel] = &acumulado{}
			if nivel <= profundidadeMaxima {
				if len(at.Itens) < maxItensListados {
					indicePasta[rel] = len(at.Itens)
					at.Itens = append(at.Itens, ItemAreaTrabalho{Caminho: rel, Pasta: true, ModificadoEm: mod})
				} else {
					at.Truncado = true
				}
			}
			return nil
		}

		tam := info.Size()
		at.TotalArquivos++
		at.TotalBytes += tam

		// soma nas pastas ancestrais
		partes := strings.Split(rel, "/")
		for i := 1; i < len(partes); i++ {
			if acc, ok := pastas[strings.Join(partes[:i], "/")]; ok {
				acc.bytes += tam
				acc.arquivos++
			}
		}

		if nivel <= profundidadeMaxima {
			if len(at.Itens) < maxItensListados {
				at.Itens = append(at.Itens, ItemAreaTrabalho{
					Caminho:      rel,
					Extensao:     strings.TrimPrefix(strings.ToLower(filepath.Ext(d.Name())), "."),
					Bytes:        tam,
					ModificadoEm: mod,
				})
			} else {
				at.Truncado = true
			}
		}
		return nil
	})

	for rel, idx := range indicePasta {
		if acc := pastas[rel]; acc != nil {
			at.Itens[idx].Bytes = acc.bytes
			at.Itens[idx].Arquivos = acc.arquivos
		}
	}
	sort.Slice(at.Itens, func(i, j int) bool {
		return strings.ToLower(at.Itens[i].Caminho) < strings.ToLower(at.Itens[j].Caminho)
	})
	return at
}
