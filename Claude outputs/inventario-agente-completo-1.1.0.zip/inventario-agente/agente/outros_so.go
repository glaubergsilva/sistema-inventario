//go:build !windows

package main

// Implementações mínimas para compilar/testar fora do Windows.
// Em Linux, "coletar" varre apenas a área de trabalho do usuário atual.

import (
	"errors"
	"os"
	"path/filepath"
	"time"
)

func executarComoServico() (bool, error) { return false, nil }

func instalar(Config) error { return errors.New("instalação suportada apenas no Windows") }
func desinstalar() error    { return errors.New("suportado apenas no Windows") }

func coletar(incluirDocumentos bool) Coleta {
	h, _ := os.Hostname()
	home, _ := os.UserHomeDir()
	c := Coleta{VersaoAgente: versao, MachineID: "teste-" + h, Hostname: h, ColetadoEm: time.Now().Format(time.RFC3339)}
	dir := os.Getenv("AREA_TRABALHO_TESTE")
	if dir == "" {
		dir = filepath.Join(home, "Desktop")
	}
	if st, err := os.Stat(dir); err == nil && st.IsDir() {
		c.AreaTrabalho = []AreaTrabalho{varrerAreaTrabalho(os.Getenv("USER"), dir, time.Minute)}
	}
	if docs := os.Getenv("DOCUMENTOS_TESTE"); incluirDocumentos && docs != "" {
		d := []AreaTrabalho{varrerAreaTrabalho(os.Getenv("USER"), docs, 2*time.Minute)}
		c.Documentos = &d
	}
	return c
}
