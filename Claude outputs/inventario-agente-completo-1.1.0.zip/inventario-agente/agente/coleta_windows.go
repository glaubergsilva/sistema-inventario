//go:build windows

package main

import (
	"encoding/base64"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"syscall"
	"time"
	"unicode/utf16"

	"golang.org/x/sys/windows"
	"golang.org/x/sys/windows/registry"
)

// Script PowerShell que consulta o WMI/CIM e devolve um JSON.
// Datas são convertidas para texto ISO para evitar o formato /Date()/ do PS 5.1.
const scriptHardware = `
$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
function D($d) { if ($d) { $d.ToString('o') } else { '' } }
$cs  = Get-CimInstance Win32_ComputerSystem
$os  = Get-CimInstance Win32_OperatingSystem
$bios = Get-CimInstance Win32_BIOS
$cpu = @(Get-CimInstance Win32_Processor)
$mem = @(Get-CimInstance Win32_PhysicalMemory)
$ld  = @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3')
$vid = @(Get-CimInstance Win32_VideoController)
$net = @(Get-CimInstance Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=True')
$pd  = @(Get-CimInstance -Namespace root\Microsoft\Windows\Storage MSFT_PhysicalDisk)
if ($pd.Count -eq 0) {
  $pd = @(Get-CimInstance Win32_DiskDrive | ForEach-Object { [pscustomobject]@{ FriendlyName=$_.Model; Size=$_.Size; MediaType=0; SerialNumber=$_.SerialNumber } })
}
$tipos = @{ 0='Desconhecido'; 3='HDD'; 4='SSD'; 5='SCM' }
[pscustomobject]@{
  hostname   = $env:COMPUTERNAME
  dominio    = [string]$cs.Domain
  usuario    = [string]$cs.UserName
  fabricante = [string]$cs.Manufacturer
  modelo     = [string]$cs.Model
  serie      = [string]$bios.SerialNumber
  bios       = ([string]$bios.SMBIOSBIOSVersion + ' ' + (D $bios.ReleaseDate)).Trim()
  memoria    = [int64]$cs.TotalPhysicalMemory
  so_nome    = [string]$os.Caption
  so_versao  = [string]$os.Version
  so_build   = [string]$os.BuildNumber
  so_arq     = [string]$os.OSArchitecture
  so_instal  = D $os.InstallDate
  so_boot    = D $os.LastBootUpTime
  cpu        = (($cpu | ForEach-Object { $_.Name.Trim() }) -join ' + ')
  nucleos    = [int](($cpu | Measure-Object NumberOfCores -Sum).Sum)
  threads    = [int](($cpu | Measure-Object NumberOfLogicalProcessors -Sum).Sum)
  modulos    = @($mem | ForEach-Object { [pscustomobject]@{ slot=[string]$_.DeviceLocator; bytes=[int64]$_.Capacity; mhz=[int]$_.Speed; fab=([string]$_.Manufacturer).Trim() } })
  video      = @($vid | ForEach-Object { [string]$_.Name })
  discos     = @($ld | ForEach-Object { [pscustomobject]@{ un=[string]$_.DeviceID; rot=[string]$_.VolumeName; fs=[string]$_.FileSystem; tam=[int64]$_.Size; livre=[int64]$_.FreeSpace } })
  fisicos    = @($pd | ForEach-Object { [pscustomobject]@{ modelo=([string]$_.FriendlyName).Trim(); tam=[int64]$_.Size; tipo=$tipos[[int]$_.MediaType]; serie=([string]$_.SerialNumber).Trim() } })
  rede       = @($net | ForEach-Object { [pscustomobject]@{ desc=[string]$_.Description; mac=[string]$_.MACAddress; ips=@($_.IPAddress | Where-Object { $_ -notlike '*:*' }) } })
} | ConvertTo-Json -Depth 5 -Compress
`

type hwPS struct {
	Hostname   string `json:"hostname"`
	Dominio    string `json:"dominio"`
	Usuario    string `json:"usuario"`
	Fabricante string `json:"fabricante"`
	Modelo     string `json:"modelo"`
	Serie      string `json:"serie"`
	BIOS       string `json:"bios"`
	Memoria    int64  `json:"memoria"`
	SONome     string `json:"so_nome"`
	SOVersao   string `json:"so_versao"`
	SOBuild    string `json:"so_build"`
	SOArq      string `json:"so_arq"`
	SOInstal   string `json:"so_instal"`
	SOBoot     string `json:"so_boot"`
	CPU        string `json:"cpu"`
	Nucleos    int    `json:"nucleos"`
	Threads    int    `json:"threads"`
	Modulos    []struct {
		Slot  string `json:"slot"`
		Bytes int64  `json:"bytes"`
		MHz   int    `json:"mhz"`
		Fab   string `json:"fab"`
	} `json:"modulos"`
	Video  []string `json:"video"`
	Discos []struct {
		Un    string `json:"un"`
		Rot   string `json:"rot"`
		FS    string `json:"fs"`
		Tam   int64  `json:"tam"`
		Livre int64  `json:"livre"`
	} `json:"discos"`
	Fisicos []struct {
		Modelo string `json:"modelo"`
		Tam    int64  `json:"tam"`
		Tipo   string `json:"tipo"`
		Serie  string `json:"serie"`
	} `json:"fisicos"`
	Rede []struct {
		Desc string   `json:"desc"`
		MAC  string   `json:"mac"`
		IPs  []string `json:"ips"`
	} `json:"rede"`
}

func executarPowerShell(script string) ([]byte, error) {
	u := utf16.Encode([]rune(script))
	b := make([]byte, len(u)*2)
	for i, v := range u {
		b[i*2] = byte(v)
		b[i*2+1] = byte(v >> 8)
	}
	ps := filepath.Join(os.Getenv("SystemRoot"), `System32\WindowsPowerShell\v1.0\powershell.exe`)
	cmd := exec.Command(ps, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
		"-EncodedCommand", base64.StdEncoding.EncodeToString(b))
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: windows.BELOW_NORMAL_PRIORITY_CLASS}
	return cmd.Output()
}

// coletar faz a coleta completa. Documentos só são varridos quando incluirDocumentos = true.
// Durante a coleta o processo roda em "modo de segundo plano" (CPU e disco em prioridade baixa).
func coletar(incluirDocumentos bool) Coleta {
	proc := windows.CurrentProcess()
	if windows.SetPriorityClass(proc, windows.PROCESS_MODE_BACKGROUND_BEGIN) == nil {
		defer windows.SetPriorityClass(proc, windows.PROCESS_MODE_BACKGROUND_END)
	}

	c := Coleta{VersaoAgente: versao, ColetadoEm: time.Now().Format(time.RFC3339)}
	c.MachineID = lerMachineGUID()
	c.Hostname, _ = os.Hostname()

	if out, err := executarPowerShell(scriptHardware); err != nil {
		c.Erros = append(c.Erros, "powershell: "+err.Error())
	} else {
		var h hwPS
		if err := json.Unmarshal(out, &h); err != nil {
			c.Erros = append(c.Erros, "json hardware: "+err.Error())
		} else {
			preencherHardware(&c, h)
		}
	}

	c.Programas = lerProgramas()
	c.AreaTrabalho = lerAreasDeTrabalho()
	if incluirDocumentos {
		docs := lerDocumentos()
		c.Documentos = &docs
	}
	if c.MachineID == "" {
		c.MachineID = strings.ToLower(c.Hostname + "-" + c.Hardware.NumeroSerie)
	}
	return c
}

func preencherHardware(c *Coleta, h hwPS) {
	if h.Hostname != "" {
		c.Hostname = h.Hostname
	}
	c.Dominio = h.Dominio
	c.UsuarioLogado = h.Usuario
	c.SO = SistemaOperacional{Nome: h.SONome, Versao: h.SOVersao, Build: h.SOBuild,
		Arquitetura: h.SOArq, DataInstalacao: h.SOInstal, UltimoBoot: h.SOBoot}
	c.Hardware = Hardware{Fabricante: strings.TrimSpace(h.Fabricante), Modelo: strings.TrimSpace(h.Modelo),
		NumeroSerie: strings.TrimSpace(h.Serie), BIOS: h.BIOS, CPU: h.CPU, CPUNucleos: h.Nucleos,
		CPUThreads: h.Threads, MemoriaBytes: h.Memoria, Video: h.Video, Modulos: []ModuloMemoria{}}
	for _, m := range h.Modulos {
		c.Hardware.Modulos = append(c.Hardware.Modulos, ModuloMemoria{Slot: m.Slot, Bytes: m.Bytes, Velocidade: m.MHz, Fabricante: m.Fab})
	}
	for _, d := range h.Discos {
		c.Discos = append(c.Discos, Disco{Unidade: d.Un, Rotulo: d.Rot, SistemaArquivos: d.FS, TamanhoBytes: d.Tam, LivreBytes: d.Livre})
	}
	for _, d := range h.Fisicos {
		c.DiscosFisicos = append(c.DiscosFisicos, DiscoFisico{Modelo: d.Modelo, TamanhoBytes: d.Tam, Tipo: d.Tipo, NumeroSerie: d.Serie})
	}
	for _, r := range h.Rede {
		c.Rede = append(c.Rede, AdaptadorRede{Descricao: r.Desc, MAC: r.MAC, IPs: r.IPs})
	}
}

func lerMachineGUID() string {
	k, err := registry.OpenKey(registry.LOCAL_MACHINE, `SOFTWARE\Microsoft\Cryptography`, registry.QUERY_VALUE|registry.WOW64_64KEY)
	if err != nil {
		return ""
	}
	defer k.Close()
	v, _, _ := k.GetStringValue("MachineGuid")
	return strings.ToLower(v)
}

// ---------- Programas instalados (registro, não usa Win32_Product) ----------

func lerProgramas() []Programa {
	vistos := map[string]bool{}
	lista := []Programa{}
	ler := func(raiz registry.Key, caminho string, flag uint32) {
		k, err := registry.OpenKey(raiz, caminho, registry.ENUMERATE_SUB_KEYS|flag)
		if err != nil {
			return
		}
		defer k.Close()
		nomes, _ := k.ReadSubKeyNames(-1)
		for _, n := range nomes {
			sk, err := registry.OpenKey(k, n, registry.QUERY_VALUE|flag)
			if err != nil {
				continue
			}
			nome, _, _ := sk.GetStringValue("DisplayName")
			sc, _, _ := sk.GetIntegerValue("SystemComponent")
			pai, _, _ := sk.GetStringValue("ParentKeyName")
			tipo, _, _ := sk.GetStringValue("ReleaseType")
			if nome = strings.TrimSpace(nome); nome == "" || sc == 1 || pai != "" ||
				strings.EqualFold(tipo, "Update") || strings.EqualFold(tipo, "Hotfix") || strings.EqualFold(tipo, "Security Update") {
				sk.Close()
				continue
			}
			ver, _, _ := sk.GetStringValue("DisplayVersion")
			ed, _, _ := sk.GetStringValue("Publisher")
			dt, _, _ := sk.GetStringValue("InstallDate")
			sk.Close()
			chave := strings.ToLower(nome + "|" + ver)
			if vistos[chave] {
				continue
			}
			vistos[chave] = true
			lista = append(lista, Programa{Nome: nome, Versao: strings.TrimSpace(ver), Editor: strings.TrimSpace(ed), DataInstalacao: formatarDataReg(dt)})
		}
	}
	const un = `SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall`
	ler(registry.LOCAL_MACHINE, un, registry.WOW64_64KEY)
	ler(registry.LOCAL_MACHINE, un, registry.WOW64_32KEY)
	// instalações por usuário (perfis carregados)
	if k, err := registry.OpenKey(registry.USERS, "", registry.ENUMERATE_SUB_KEYS); err == nil {
		sids, _ := k.ReadSubKeyNames(-1)
		k.Close()
		for _, sid := range sids {
			if strings.HasSuffix(sid, "_Classes") || !strings.HasPrefix(sid, "S-1-5-21-") && !strings.HasPrefix(sid, "S-1-12-1-") {
				continue
			}
			ler(registry.USERS, sid+`\`+un, 0)
		}
	}
	sort.Slice(lista, func(i, j int) bool { return strings.ToLower(lista[i].Nome) < strings.ToLower(lista[j].Nome) })
	return lista
}

func formatarDataReg(s string) string {
	s = strings.TrimSpace(s)
	if len(s) == 8 {
		if t, err := time.Parse("20060102", s); err == nil {
			return t.Format("2006-01-02")
		}
	}
	return s
}

// ---------- Pastas dos perfis (Área de trabalho / Documentos) ----------

// pastaPerfil descreve uma pasta conhecida do perfil do usuário.
type pastaPerfil struct {
	valorRegistro string   // nome em "User Shell Folders" (Desktop, Personal)
	nomesPadrao   []string // nomes no perfil e no OneDrive
	limiteTempo   time.Duration
}

var (
	pastaAreaTrabalho = pastaPerfil{"Desktop", []string{"Desktop", "Área de Trabalho"}, 60 * time.Second}
	pastaDocumentos   = pastaPerfil{"Personal", []string{"Documents", "Documentos"}, 2 * time.Minute}
)

func lerAreasDeTrabalho() []AreaTrabalho { return lerPastaDosPerfis(pastaAreaTrabalho) }
func lerDocumentos() []AreaTrabalho      { return lerPastaDosPerfis(pastaDocumentos) }

func lerPastaDosPerfis(tipo pastaPerfil) []AreaTrabalho {
	res := []AreaTrabalho{}
	k, err := registry.OpenKey(registry.LOCAL_MACHINE, `SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList`, registry.ENUMERATE_SUB_KEYS|registry.WOW64_64KEY)
	if err != nil {
		return res
	}
	sids, _ := k.ReadSubKeyNames(-1)
	k.Close()

	for _, sid := range sids {
		if !strings.HasPrefix(sid, "S-1-5-21-") && !strings.HasPrefix(sid, "S-1-12-1-") {
			continue // ignora contas de sistema
		}
		pk, err := registry.OpenKey(registry.LOCAL_MACHINE, `SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList\`+sid, registry.QUERY_VALUE|registry.WOW64_64KEY)
		if err != nil {
			continue
		}
		perfil, _, _ := pk.GetStringValue("ProfileImagePath")
		pk.Close()
		perfil = expandir(perfil)
		if st, err := os.Stat(perfil); err != nil || !st.IsDir() {
			continue
		}
		usuario := nomeDaConta(sid, filepath.Base(perfil))
		for _, dir := range caminhosDaPasta(sid, perfil, tipo) {
			if strings.HasPrefix(dir, `\\`) {
				res = append(res, AreaTrabalho{Usuario: usuario, Caminho: dir, Redirecionada: true, Itens: []ItemAreaTrabalho{}})
				continue
			}
			res = append(res, varrerAreaTrabalho(usuario, dir, tipo.limiteTempo))
		}
	}
	return res
}

func caminhosDaPasta(sid, perfil string, tipo pastaPerfil) []string {
	cand := []string{}
	// 1) caminho configurado no perfil (se o hive do usuário estiver carregado)
	if k, err := registry.OpenKey(registry.USERS, sid+`\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders`, registry.QUERY_VALUE); err == nil {
		if v, _, err := k.GetStringValue(tipo.valorRegistro); err == nil && v != "" {
			v = strings.ReplaceAll(v, "%USERPROFILE%", perfil)
			v = strings.ReplaceAll(v, "%userprofile%", perfil)
			cand = append(cand, expandir(v))
		}
		k.Close()
	}
	// 2) locais padrão e OneDrive (Known Folder Move)
	cand = append(cand, filepath.Join(perfil, tipo.nomesPadrao[0]))
	if od, _ := filepath.Glob(filepath.Join(perfil, "OneDrive*")); len(od) > 0 {
		for _, d := range od {
			for _, n := range tipo.nomesPadrao {
				cand = append(cand, filepath.Join(d, n))
			}
		}
	}
	vistos := map[string]bool{}
	ok := []string{}
	for _, c := range cand {
		chave := strings.ToLower(filepath.Clean(c))
		if vistos[chave] {
			continue
		}
		vistos[chave] = true
		// caminhos de rede (redirecionamento por GPO) não são varridos: já estão no servidor
		if strings.HasPrefix(c, `\\`) {
			ok = append(ok, c)
			continue
		}
		if st, err := os.Stat(c); err == nil && st.IsDir() {
			ok = append(ok, c)
		}
	}
	return ok
}

func expandir(s string) string {
	if !strings.Contains(s, "%") {
		return s
	}
	p, err := syscall.UTF16PtrFromString(s)
	if err != nil {
		return s
	}
	buf := make([]uint16, 1024)
	n, err := windows.ExpandEnvironmentStrings(p, &buf[0], uint32(len(buf)))
	if err != nil || n == 0 {
		return s
	}
	return syscall.UTF16ToString(buf[:n])
}

func nomeDaConta(sid, padrao string) string {
	s, err := windows.StringToSid(sid)
	if err != nil {
		return padrao
	}
	conta, dominio, _, err := s.LookupAccount("")
	if err != nil || conta == "" {
		return padrao
	}
	if dominio != "" {
		return fmt.Sprintf(`%s\%s`, dominio, conta)
	}
	return conta
}
