<#
  Instala o Agente de Inventário de TI nesta estação.
  Executar como Administrador:
    powershell -ExecutionPolicy Bypass -File instalar.ps1 -Servidor https://inventario.seudominio.com.br -Token SEU_TOKEN

  Para implantação em massa via GPO (script de inicialização do computador), deixe o
  agente-inventario.exe numa pasta de rede e use o parâmetro -Exe \\servidor\share\agente-inventario.exe
#>
param(
  [Parameter(Mandatory = $true)][string]$Servidor,
  [Parameter(Mandatory = $true)][string]$Token,
  [string]$Exe = "",
  [int]$Intervalo = 4
)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = 'Tls12'

$destino = Join-Path $env:TEMP 'agente-inventario.exe'
if ($Exe) {
  Copy-Item $Exe $destino -Force
} else {
  Invoke-WebRequest "$($Servidor.TrimEnd('/'))/downloads/agente-inventario.exe" -OutFile $destino -UseBasicParsing
}
& $destino instalar -servidor $Servidor -token $Token -intervalo $Intervalo
if ($LASTEXITCODE -ne 0) { throw "Falha na instalação do agente (código $LASTEXITCODE)" }
