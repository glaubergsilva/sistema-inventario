module inventario/agente

go 1.24.7

require golang.org/x/sys v0.41.0
