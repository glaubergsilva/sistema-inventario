package main

import (
	"encoding/json"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strings"
	"time"
)

var versao = "1.1.0" // sobrescrito no build via -ldflags "-X main.versao=..."

const nomeServico = "InventarioAgente"

type Config struct {
	Servidor       string `json:"servidor"`                   // ex.: https://inventario.suaempresa.com.br
	TokenEmpresa   string `json:"token_empresa"`              // gerado no cadastro da empresa no portal
	IntervaloHoras int    `json:"intervalo_horas"`            // padrão 4
	IntervaloDocs  int    `json:"intervalo_documentos_horas"` // padrão 24
	Proxy          string `json:"proxy,omitempty"`            // opcional: http://proxy:3128
}

func dirDados() string {
	base := os.Getenv("ProgramData")
	if base == "" {
		base = os.TempDir()
	}
	return filepath.Join(base, "InventarioAgente")
}

func caminhoConfig() string { return filepath.Join(dirDados(), "config.json") }

func carregarConfig() (Config, error) {
	var c Config
	b, err := os.ReadFile(caminhoConfig())
	if err != nil {
		return c, fmt.Errorf("não foi possível ler %s: %w", caminhoConfig(), err)
	}
	if err := json.Unmarshal(b, &c); err != nil {
		return c, fmt.Errorf("config.json inválido: %w", err)
	}
	c.normalizar()
	if c.Servidor == "" || c.TokenEmpresa == "" {
		return c, fmt.Errorf("config.json sem servidor ou token_empresa")
	}
	return c, nil
}

func (c *Config) normalizar() {
	c.Servidor = strings.TrimRight(strings.TrimSpace(c.Servidor), "/")
	c.TokenEmpresa = strings.TrimSpace(c.TokenEmpresa)
	if c.IntervaloHoras <= 0 {
		c.IntervaloHoras = 4
	}
	if c.IntervaloDocs <= 0 {
		c.IntervaloDocs = 24
	}
}

func salvarConfig(c Config) error {
	if err := os.MkdirAll(dirDados(), 0o755); err != nil {
		return err
	}
	b, _ := json.MarshalIndent(c, "", "  ")
	return os.WriteFile(caminhoConfig(), b, 0o644)
}

// iniciarLog grava em ProgramData\InventarioAgente\agente.log (rotaciona em 1 MB).
func iniciarLog() {
	_ = os.MkdirAll(dirDados(), 0o755)
	p := filepath.Join(dirDados(), "agente.log")
	if st, err := os.Stat(p); err == nil && st.Size() > 1<<20 {
		_ = os.Rename(p, p+".1")
	}
	f, err := os.OpenFile(p, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
	if err == nil {
		log.SetOutput(f)
	}
	log.SetFlags(log.LstdFlags)
}

// estado guarda informações entre ciclos (ex.: última varredura de Documentos).
type estado struct {
	UltimaVarreduraDocs time.Time `json:"ultima_varredura_documentos"`
}

func caminhoEstado() string { return filepath.Join(dirDados(), "estado.json") }

func lerEstado() estado {
	var e estado
	if b, err := os.ReadFile(caminhoEstado()); err == nil {
		_ = json.Unmarshal(b, &e)
	}
	return e
}

func salvarEstado(e estado) {
	b, _ := json.MarshalIndent(e, "", "  ")
	_ = os.WriteFile(caminhoEstado(), b, 0o644)
}
