package main

import (
	"bytes"
	"compress/gzip"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"time"
)

func enviarColeta(c Config, coleta Coleta) error {
	corpo, err := json.Marshal(coleta)
	if err != nil {
		return err
	}
	// guarda a última coleta para diagnóstico local
	_ = os.WriteFile(filepath.Join(dirDados(), "ultima-coleta.json"), corpo, 0o644)

	var gz bytes.Buffer
	w := gzip.NewWriter(&gz)
	_, _ = w.Write(corpo)
	_ = w.Close()

	req, err := http.NewRequest(http.MethodPost, c.Servidor+"/api/agente/coleta", &gz)
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", "Bearer "+c.TokenEmpresa)
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Content-Encoding", "gzip")
	req.Header.Set("User-Agent", "InventarioAgente/"+versao)

	transporte := &http.Transport{Proxy: http.ProxyFromEnvironment}
	if c.Proxy != "" {
		if u, err := url.Parse(c.Proxy); err == nil {
			transporte.Proxy = http.ProxyURL(u)
		}
	}
	cli := &http.Client{Timeout: 60 * time.Second, Transport: transporte}
	resp, err := cli.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	msg, _ := io.ReadAll(io.LimitReader(resp.Body, 2048))
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("portal respondeu %d: %s", resp.StatusCode, string(msg))
	}
	return nil
}
