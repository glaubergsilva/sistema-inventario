//go:build windows

package main

import (
	"fmt"
	"io"
	"log"
	"math/rand"
	"os"
	"path/filepath"
	"time"

	"golang.org/x/sys/windows"
	"golang.org/x/sys/windows/svc"
	"golang.org/x/sys/windows/svc/mgr"
)

type servico struct{}

func (s *servico) Execute(args []string, req <-chan svc.ChangeRequest, status chan<- svc.Status) (bool, uint32) {
	status <- svc.Status{State: svc.StartPending}
	status <- svc.Status{State: svc.Running, Accepts: svc.AcceptStop | svc.AcceptShutdown}
	log.Printf("serviço iniciado (versão %s)", versao)

	// primeira coleta 1–3 min após iniciar (rede pronta, sem pico no boot de várias máquinas)
	espera := time.Duration(60+rand.Intn(120)) * time.Second
	timer := time.NewTimer(espera)
	for {
		select {
		case <-timer.C:
			timer.Reset(cicloColeta())
		case c := <-req:
			switch c.Cmd {
			case svc.Interrogate:
				status <- c.CurrentStatus
			case svc.Stop, svc.Shutdown:
				log.Printf("serviço parando")
				status <- svc.Status{State: svc.StopPending}
				return false, 0
			}
		}
	}
}

// cicloColeta coleta, envia e devolve o tempo até a próxima execução.
func cicloColeta() time.Duration {
	cfg, err := carregarConfig()
	if err != nil {
		log.Printf("erro de configuração: %v", err)
		return 30 * time.Minute
	}
	ini := time.Now()
	est := lerEstado()
	comDocs := time.Since(est.UltimaVarreduraDocs) >= time.Duration(cfg.IntervaloDocs)*time.Hour
	col := coletar(comDocs)
	if err := enviarColeta(cfg, col); err != nil {
		log.Printf("falha no envio (%s): %v — nova tentativa em 15 min", time.Since(ini).Round(time.Second), err)
		return 15 * time.Minute
	}
	if comDocs {
		est.UltimaVarreduraDocs = time.Now()
		salvarEstado(est)
	}
	log.Printf("coleta enviada: %d programas, %d áreas de trabalho, documentos=%v, %s", len(col.Programas), len(col.AreaTrabalho), comDocs, time.Since(ini).Round(time.Second))
	return time.Duration(cfg.IntervaloHoras) * time.Hour
}

func executarComoServico() (bool, error) {
	ehServico, err := svc.IsWindowsService()
	if err != nil || !ehServico {
		return false, err
	}
	iniciarLog()
	return true, svc.Run(nomeServico, &servico{})
}

func dirInstalacao() string {
	pf := os.Getenv("ProgramFiles")
	if pf == "" {
		pf = `C:\Program Files`
	}
	return filepath.Join(pf, "InventarioAgente")
}

func passo(msg string) { fmt.Println(" -", msg) }

func instalar(cfg Config) error {
	cfg.normalizar()
	if cfg.Servidor == "" || cfg.TokenEmpresa == "" {
		return fmt.Errorf("informe -servidor e -token")
	}
	if !windows.GetCurrentProcessToken().IsElevated() {
		return fmt.Errorf("abra o PowerShell como Administrador e execute novamente")
	}
	passo("gravando configuração em " + caminhoConfig())
	if err := salvarConfig(cfg); err != nil {
		return fmt.Errorf("salvando configuração: %w", err)
	}

	// copia o executável para Program Files
	origem, _ := os.Executable()
	if err := os.MkdirAll(dirInstalacao(), 0o755); err != nil {
		return err
	}
	destino := filepath.Join(dirInstalacao(), "agente-inventario.exe")

	passo("conectando ao gerenciador de serviços")
	m, err := mgr.Connect()
	if err != nil {
		return fmt.Errorf("execute como Administrador (%w)", err)
	}
	defer m.Disconnect()

	// se já existir, para e remove para atualizar
	if s, err := m.OpenService(nomeServico); err == nil {
		passo("removendo instalação anterior")
		_, _ = s.Control(svc.Stop)
		time.Sleep(2 * time.Second)
		_ = s.Delete()
		s.Close()
		time.Sleep(2 * time.Second)
	}

	if !mesmoArquivo(origem, destino) {
		passo("copiando executável para " + destino)
		if err := copiarArquivo(origem, destino); err != nil {
			return fmt.Errorf("copiando executável: %w", err)
		}
	}

	passo("criando serviço " + nomeServico)
	s, err := m.CreateService(nomeServico, destino, mgr.Config{
		DisplayName:      "Agente de Inventário de TI",
		Description:      "Coleta informações de hardware, software e área de trabalho e envia ao portal de inventário.",
		StartType:        mgr.StartAutomatic,
		DelayedAutoStart: true,
	})
	if err != nil {
		return fmt.Errorf("criando serviço: %w", err)
	}
	defer s.Close()
	_ = s.SetRecoveryActions([]mgr.RecoveryAction{
		{Type: mgr.ServiceRestart, Delay: time.Minute},
		{Type: mgr.ServiceRestart, Delay: time.Minute},
		{Type: mgr.ServiceRestart, Delay: 5 * time.Minute},
	}, 86400)
	passo("iniciando serviço")
	if err := s.Start(); err != nil {
		return fmt.Errorf("iniciando serviço: %w", err)
	}
	return nil
}

func desinstalar() error {
	m, err := mgr.Connect()
	if err != nil {
		return fmt.Errorf("execute como Administrador (%w)", err)
	}
	defer m.Disconnect()
	s, err := m.OpenService(nomeServico)
	if err != nil {
		return fmt.Errorf("serviço não encontrado")
	}
	_, _ = s.Control(svc.Stop)
	time.Sleep(2 * time.Second)
	err = s.Delete()
	s.Close()
	return err
}

func mesmoArquivo(a, b string) bool {
	sa, err1 := os.Stat(a)
	sb, err2 := os.Stat(b)
	return err1 == nil && err2 == nil && os.SameFile(sa, sb)
}

func copiarArquivo(origem, destino string) error {
	in, err := os.Open(origem)
	if err != nil {
		return err
	}
	defer in.Close()
	out, err := os.Create(destino)
	if err != nil {
		return err
	}
	if _, err := io.Copy(out, in); err != nil {
		out.Close()
		return err
	}
	return out.Close()
}
