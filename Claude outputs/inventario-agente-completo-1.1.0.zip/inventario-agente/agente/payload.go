package main

// Coleta é o pacote de dados enviado ao portal a cada ciclo.
type Coleta struct {
	VersaoAgente  string             `json:"versao_agente"`
	MachineID     string             `json:"machine_id"`
	Hostname      string             `json:"hostname"`
	Dominio       string             `json:"dominio"`
	UsuarioLogado string             `json:"usuario_logado"`
	ColetadoEm    string             `json:"coletado_em"`
	SO            SistemaOperacional `json:"so"`
	Hardware      Hardware           `json:"hardware"`
	Discos        []Disco            `json:"discos"`
	DiscosFisicos []DiscoFisico      `json:"discos_fisicos"`
	Rede          []AdaptadorRede    `json:"rede"`
	Programas     []Programa         `json:"programas"`
	AreaTrabalho  []AreaTrabalho     `json:"area_trabalho"`
	Documentos    *[]AreaTrabalho    `json:"documentos,omitempty"` // ausente = não varrido neste ciclo
	Erros         []string           `json:"erros,omitempty"`
}

type SistemaOperacional struct {
	Nome           string `json:"nome"`
	Versao         string `json:"versao"`
	Build          string `json:"build"`
	Arquitetura    string `json:"arquitetura"`
	DataInstalacao string `json:"data_instalacao"`
	UltimoBoot     string `json:"ultimo_boot"`
}

type Hardware struct {
	Fabricante   string          `json:"fabricante"`
	Modelo       string          `json:"modelo"`
	NumeroSerie  string          `json:"numero_serie"`
	BIOS         string          `json:"bios"`
	CPU          string          `json:"cpu"`
	CPUNucleos   int             `json:"cpu_nucleos"`
	CPUThreads   int             `json:"cpu_threads"`
	MemoriaBytes int64           `json:"memoria_bytes"`
	Modulos      []ModuloMemoria `json:"modulos_memoria"`
	Video        []string        `json:"video"`
}

type ModuloMemoria struct {
	Slot       string `json:"slot"`
	Bytes      int64  `json:"bytes"`
	Velocidade int    `json:"velocidade_mhz"`
	Fabricante string `json:"fabricante"`
}

type Disco struct {
	Unidade         string `json:"unidade"`
	Rotulo          string `json:"rotulo"`
	SistemaArquivos string `json:"sistema_arquivos"`
	TamanhoBytes    int64  `json:"tamanho_bytes"`
	LivreBytes      int64  `json:"livre_bytes"`
}

type DiscoFisico struct {
	Modelo       string `json:"modelo"`
	TamanhoBytes int64  `json:"tamanho_bytes"`
	Tipo         string `json:"tipo"` // SSD, HDD, ...
	NumeroSerie  string `json:"numero_serie"`
}

type AdaptadorRede struct {
	Descricao string   `json:"descricao"`
	MAC       string   `json:"mac"`
	IPs       []string `json:"ips"`
}

type Programa struct {
	Nome           string `json:"nome"`
	Versao         string `json:"versao"`
	Editor         string `json:"editor"`
	DataInstalacao string `json:"data_instalacao"`
}

// AreaTrabalho representa a área de trabalho de um perfil de usuário.
type AreaTrabalho struct {
	Usuario       string             `json:"usuario"`
	Caminho       string             `json:"caminho"`
	TotalArquivos int                `json:"total_arquivos"`
	TotalPastas   int                `json:"total_pastas"`
	TotalBytes    int64              `json:"total_bytes"`
	Truncado      bool               `json:"truncado"`
	Redirecionada bool               `json:"redirecionada"`            // área de trabalho na rede (GPO)
	TempoEsgotado bool               `json:"tempo_esgotado,omitempty"` // varredura interrompida pelo limite de tempo: totais parciais
	Itens         []ItemAreaTrabalho `json:"itens"`
}

type ItemAreaTrabalho struct {
	Caminho      string `json:"caminho"` // relativo à área de trabalho, separador "/"
	Pasta        bool   `json:"pasta"`
	Extensao     string `json:"extensao,omitempty"`
	Bytes        int64  `json:"bytes"`
	Arquivos     int    `json:"arquivos,omitempty"` // para pastas: qtde de arquivos dentro
	ModificadoEm string `json:"modificado_em"`
}
