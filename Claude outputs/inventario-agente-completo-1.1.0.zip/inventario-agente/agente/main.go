package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"time"
)

const ajuda = `Agente de Inventário de TI %s

Uso:
  agente-inventario.exe instalar -servidor URL -token TOKEN [-intervalo 4] [-intervalo-documentos 24] [-proxy URL]
      Instala/atualiza o serviço (executar como Administrador).
  agente-inventario.exe desinstalar
      Remove o serviço.
  agente-inventario.exe coletar [-enviar]
      Executa uma coleta agora e mostra o JSON (com -enviar, envia ao portal).
  agente-inventario.exe versao
`

func main() {
	if ok, err := executarComoServico(); ok {
		if err != nil {
			os.Exit(1)
		}
		return
	}

	if len(os.Args) < 2 {
		fmt.Printf(ajuda, versao)
		return
	}

	switch os.Args[1] {
	case "instalar":
		fs := flag.NewFlagSet("instalar", flag.ExitOnError)
		servidor := fs.String("servidor", "", "URL do portal")
		token := fs.String("token", "", "token de instalação da empresa")
		intervalo := fs.Int("intervalo", 4, "intervalo entre coletas, em horas")
		intervaloDocs := fs.Int("intervalo-documentos", 24, "intervalo entre varreduras da pasta Documentos, em horas")
		proxy := fs.String("proxy", "", "proxy HTTP opcional")
		_ = fs.Parse(os.Args[2:])
		fmt.Printf("Instalando Agente de Inventário %s...\n", versao)
		if err := instalar(Config{Servidor: *servidor, TokenEmpresa: *token, IntervaloHoras: *intervalo, IntervaloDocs: *intervaloDocs, Proxy: *proxy}); err != nil {
			fmt.Fprintln(os.Stderr, "Erro:", err)
			os.Exit(1)
		}
		fmt.Println("Agente instalado e iniciado. A primeira coleta ocorre em até 3 minutos.")

	case "desinstalar":
		if err := desinstalar(); err != nil {
			fmt.Fprintln(os.Stderr, "Erro:", err)
			os.Exit(1)
		}
		fmt.Println("Agente removido.")

	case "coletar":
		fs := flag.NewFlagSet("coletar", flag.ExitOnError)
		enviar := fs.Bool("enviar", false, "enviar ao portal")
		_ = fs.Parse(os.Args[2:])
		col := coletar(true) // coleta manual sempre inclui Documentos
		if *enviar {
			cfg, err := carregarConfig()
			if err == nil {
				err = enviarColeta(cfg, col)
			}
			if err != nil {
				fmt.Fprintln(os.Stderr, "Erro no envio:", err)
				os.Exit(1)
			}
			est := lerEstado()
			est.UltimaVarreduraDocs = time.Now()
			salvarEstado(est)
			fmt.Println("Coleta enviada com sucesso.")
			return
		}
		b, _ := json.MarshalIndent(col, "", "  ")
		fmt.Println(string(b))

	case "versao", "-v", "--version":
		fmt.Println(versao)

	default:
		fmt.Printf(ajuda, versao)
	}
}
