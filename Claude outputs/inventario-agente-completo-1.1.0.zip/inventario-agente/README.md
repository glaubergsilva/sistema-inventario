# Inventário de TI — Agente + Portal

Sistema de coleta de inventário das estações Windows:

- **agente/** — serviço Windows (Go) que coleta hardware, sistema, discos, rede, programas instalados e a lista de arquivos/pastas da **área de trabalho** de cada perfil, e envia ao portal.
- **portal/** — aplicação web (Next.js) com empresas, usuários com permissão por empresa, estações, relatório de área de trabalho e exportação CSV. Banco Cloudflare D1 (produção) ou SQLite local (desenvolvimento).

Rodapé do portal: “criado por Glauber G. Silva”.

---

## 1. Portal

### Rodar localmente

```bash
cd portal
npm install
npm run dev            # http://localhost:3000 (usa dados-local.sqlite)
```

No primeiro acesso a tela de login pede para criar o **usuário administrador**.

### Publicar (GitHub + Vercel + Cloudflare D1)

1. Crie o banco no Cloudflare: `npx wrangler d1 create inventario` e anote o `database_id`.
2. Aplique o esquema: `npx wrangler d1 execute inventario --remote --file=db/schema.sql`
   (opcional — o portal também cria as tabelas sozinho).
3. Crie um **API Token** no Cloudflare com permissão *Account → D1 → Edit*.
4. Na Vercel, importe o repositório (pasta raiz: `portal`) e defina as variáveis:

| Variável | Valor |
|---|---|
| `SESSION_SECRET` | texto aleatório longo (`openssl rand -base64 32`) |
| `PORTAL_URL` | URL pública do portal, ex.: `https://inventario.thermojet.com.br` |
| `CF_ACCOUNT_ID` | ID da conta Cloudflare |
| `CF_D1_DATABASE_ID` | ID do banco D1 |
| `CF_API_TOKEN` | token criado no passo 3 |

### Uso

1. **Empresas** → cadastre Thermojet, Aestus, 4Pipe… Cada uma recebe um **token de instalação**.
2. **Usuários** → cadastre os técnicos e marque quais empresas cada um pode ver.
3. Instale o agente nas estações com o comando mostrado na empresa (seção abaixo).

---

## 2. Agente

O executável pronto está em `portal/public/downloads/agente-inventario.exe` (servido pelo portal em `/downloads/agente-inventario.exe`).

### Instalar em uma estação (PowerShell como Administrador)

O portal mostra o comando pronto para cada empresa. Manualmente:

```powershell
agente-inventario.exe instalar -servidor https://inventario.seudominio.com.br -token TOKEN_DA_EMPRESA
```

Isso copia o executável para `C:\Program Files\InventarioAgente`, grava a configuração em
`C:\ProgramData\InventarioAgente\config.json` e cria o serviço **InventarioAgente** (início automático atrasado, com reinício em caso de falha).

Em massa: use `agente/instalar.ps1` como script de inicialização de computador via GPO, apontando `-Exe` para uma pasta de rede.

### Outros comandos

```text
agente-inventario.exe coletar            # mostra o JSON da coleta (diagnóstico)
agente-inventario.exe coletar -enviar    # coleta e envia agora
agente-inventario.exe desinstalar
agente-inventario.exe versao
```

Log: `C:\ProgramData\InventarioAgente\agente.log` · última coleta enviada: `ultima-coleta.json`.

### O que é coletado

| Item | Fonte |
|---|---|
| Fabricante, modelo, nº de série, BIOS, CPU, memória e módulos, vídeo | WMI/CIM |
| Sistema operacional, build, data de instalação, último boot | WMI/CIM |
| Unidades (tamanho/livre), discos físicos (SSD/HDD) | WMI/CIM |
| Adaptadores de rede, MAC, IPv4 | WMI/CIM |
| Programas instalados | Registro (`Uninstall`, 64/32 bits e por usuário) — não usa `Win32_Product` |
| Área de trabalho de **todos os perfis** | Sistema de arquivos |

**Área de trabalho:** inclui áreas redirecionadas para o OneDrive. Áreas redirecionadas para a rede via GPO aparecem como “na rede” e não são varridas. Atalhos (`.lnk`, `.url`), `desktop.ini` e temporários (`~$...`) são ignorados. Lista até 3 níveis de subpastas e 2.000 itens por perfil; os totais (arquivos/tamanho) consideram tudo. **Somente metadados** (nome, tamanho, data) são coletados — nunca o conteúdo dos arquivos.

> LGPD: nomes de arquivos podem conter dados pessoais. Recomenda-se prever a coleta na política de uso de recursos de TI e comunicar os colaboradores.

Intervalo padrão: a cada 4 horas (primeira coleta 1–3 min após o serviço iniciar; em caso de falha de envio, nova tentativa em 15 min).

### Compilar o agente

Requer Go 1.24+:

```bash
cd agente
go mod tidy
GOOS=windows GOARCH=amd64 go build -trimpath -ldflags "-s -w -X main.versao=1.0.0" -o agente-inventario.exe .
```

**Antivírus:** executáveis sem assinatura digital podem ser bloqueados ou colocados em quarentena por alguns antivírus. Para produção, assine o `.exe` com um certificado de assinatura de código (ou crie uma exceção na console do antivírus).
